# reactNativeApp

reactNativeApp  
Basic weather app showing the temperature and the weather condition of your current location.  
Built using React Native, Hooks and OpenWeatherMap API
